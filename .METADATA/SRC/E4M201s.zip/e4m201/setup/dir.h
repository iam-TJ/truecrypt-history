/* Everything below this line is automatically updated by the -mkproto-tool- */

int mkfulldir ( char *path , BOOL bCheckonly );
int mkfulldir_internal ( char *path );
