//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Dlgs.rc
//
#define IDD_ABOUT_DLG                   25000
#define IDD_WARNING_DLG                 25001
#define IDI_E4M                         25002
#define IDI_WARNING_ICON                25004
#define IDS_ABOUTBOX                    25005
#define IDS_NOFONT                      25006
#define IDS_OUTOFMEMORY                 25007
#define IDS_INIT_REGISTER               25008
#define IDS_PASSWORD_HELP0              25009
#define IDS_PASSWORD_HELP1              25010
#define IDS_PASSWORD_HELP2              25011
#define IDS_PASSWORD_HELP3              25012
#define IDS_NODRIVER                    25013
#define IDD_RAWDEVICES_DLG              25014
#define IDS_RAWDEVICES                  25014
#define IDC_DEVICE                      25015
#define IDS_NOSERVICE                   25015
#define IDS_SERVICE_NOT_RUNNING         25016
#define IDS_INIT_MUTEX                  25017
#define IDS_TWO_INSTANCES               25018
#define IDS_VOL_FORMAT_BAD              25023
#define IDS_PASSWORD_WRONG              25024
#define IDS_OPENFILES_DRIVER            25025
#define IDS_BAD_DRIVE_LETTER            25026
#define IDS_UNKNOWN                     25027
#define IDS_NOT_FOUND                   25028
#define IDS_VOL_SIZE_WRONG              25029
#define IDS_COMPRESSION_NOT_SUPPORTED   25030
#define IDS_DRIVELETTERS                25031
#define IDS_OPENFILES_LOCK              25032
#define IDS_SYMLINK                     25033
#define IDS_SYMLINK_REMOVE              25034
#define IDS_INIT_RAND                   25035
#define IDS_CREATE_FAILED               25036
#define IDS_ACCESSMODEFAIL              25037
#define IDS_OVERWRITEPROMPT             25038
#define IDS_OVERWRITEPROMPT_DEVICE      25039
#define IDS_WIPE_CACHE                  25040
#define IDS_VOL_TOO_SMALL               25041
#define IDS_WRONG_VOL_VERSION           25042
#define IDS_WRONG_VOL_TYPE              25043
#define IDS_VOL_SEEKING                 25044
#define IDS_VOL_WRITING                 25045
#define IDS_PASSWORD_CHANGED            25046
#define IDS_NO_OS_VER                   25047
#define IDS_VOL_ALREADY_MOUNTED         25048
#define IDS_NO_FREE_DRIVES              25049
#define IDS_NO_FREE_SLOTS               25050
#define IDS_VOL_MOUNT_FAILED            25051
#define IDS_FILE_OPEN_FAILED            25052
#define IDS_INVALID_DEVICE              25053
#define IDS_VOL_READING                 25054
#define IDS_ACCESS_DENIED               25055
#define IDS_DRIVER_VERSION              25056
#define IDC_NEVER_SHOW                  25200
#define IDC_WARNING_TEXT                25201

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
