/* Copyright (C) 1998-99 Paul Le Roux. All rights reserved. Please see the
   file license.txt for full license details. paulca@rocketmail.com */

/* Everything below this line is automatically updated by the -mkproto-tool- */

int FormatVolume ( char *lpszFilename , BOOL bDevice , long size , int nVolType , char *lpszPassword , int cipher , int pkcs5 , fatparams *ft , HWND hwndDlg );
