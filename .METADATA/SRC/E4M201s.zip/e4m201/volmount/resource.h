//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by volmount.rc
//
#define IDS_MOUNT_BUTTON                6
#define IDS_UNMOUNT_BUTTON              7
#define IDS_OPEN_TITLE                  9
#define IDS_TITLE                       13
#define IDS_PASSWORD                    27
#define IDD_MOUNT_DLG                   102
#define IDD_PASSWORDCHANGE_DLG          111
#define IDB_TREE_VIEW_NORMAL            113
#define IDC_VERIFY                      1008
#define IDC_OLD_PASSWORD                1009
#define IDC_BOX_HELP                    1011
#define IDC_TREE                        1015
#define IDC_CACHE                       1016
#define IDC_NO_HISTORY                  1017
#define IDC_VOLUME                      2006
#define IDC_PASSWORD                    2007
#define IDC_NO_DRIVES_STATIC            2011
#define IDC_BROWSE_FILES                2013
#define IDC_VOLUME_STATIC               2015
#define IDC_PASSWORD_STATIC             2016
#define IDC_BROWSE_DEVICES              2017
#define IDC_CHANGE_PASSWORD             2019
#define IDC_WIPE_CACHE                  2020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        118
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
