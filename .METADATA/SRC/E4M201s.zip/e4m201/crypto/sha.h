void ShaTransform0 (unsigned long *hash, unsigned long *data);
