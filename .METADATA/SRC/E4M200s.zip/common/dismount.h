/* Everything below this line is automatically updated by the -mkproto-tool- */

void UnmountAllVolumes ( HWND hwndDlg , DWORD *os_error , int *err );
BOOL UnmountVolume ( HWND hwndDlg , int nDosDriveNo , DWORD *os_error , int *err );
BOOL DismountVolume ( HWND hwndDlg , char *lpszVolMountName , DWORD *os_error , int *err );
